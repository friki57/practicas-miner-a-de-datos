const express = require('express');

var app = express();

var puerto = process.env.PORT || 3000;
//
// var favicon = require('serve-favicon');
// app.use(favicon(path.join(__dirname,'public','img','favicon.ico')));



app.use('/', express.static('public/'));

app.listen(puerto, ()=>
{
  console.log("Servidor lanzado en el puerto:",puerto);
});
