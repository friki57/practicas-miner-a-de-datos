var firebaseConfig = {
  apiKey: "AIzaSyBXlSm8iJa8b6cwqEs-yB0gg8ZktWiartg",
  authDomain: "navegacion-72ca7.firebaseapp.com",
  databaseURL: "https://navegacion-72ca7.firebaseio.com",
  projectId: "navegacion-72ca7",
  storageBucket: "",
  messagingSenderId: "818987144864",
  appId: "1:818987144864:web:b252daeea3f7fb32b81bc5"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
base = firebase.database();
var ref = base.ref('mineriaOptimismo');
ref.on('value', (data)=> {
  keys = Object.keys(data.val());
  
  document.getElementById("contador").innerHTML = "Hay " + keys.length + " encuestas respondidas.";
},
  (err)=> {
    console.log(err);
    console.log("error")
  });

var ingresar = true;
document.getElementById("enviar").addEventListener("click",()=>
{
  var feliz = document.getElementById("feliz").value;
  var triste = document.getElementById("triste").value;
  var preocupado = document.getElementById("preocupado").value;
  var opt = document.getElementById("opt").checked;
  var pes = document.getElementById("pes").checked;
  var datos = {
    feliz,
    triste,
    preocupado,
    opt,
    pes
  }
  if(ingresar==true)
  {
    guardarBase(datos);
    setTimeout(()=>
    {
      window.location.reload();
    },1000);
  }
});

function guardarBase(datos) {
  ingresar = false;
  ref.push(datos);
}
